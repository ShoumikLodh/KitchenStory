export class Kitchen1{
    Item:number;
    Name:string;
    Cost:number;
    Rating:number;
    qnt:number;
    Img:string;
}
export class Kitchens1{
    constructor(public Item="", public Name="",public Cost="", public Rating="",public qnt="",public Img=""){

    }
}